@echo off
set "SASISOPA_LANZADOR=%LOCALAPPDATA%\Programs\SASISOPA-Actualizado\Abrir-SASISOPA.cmd"
if not exist "%SASISOPA_LANZADOR%" (
  echo Ejecuta INSTALAR.bat primero.
  pause
  exit /b 1
)
call "%SASISOPA_LANZADOR%"
