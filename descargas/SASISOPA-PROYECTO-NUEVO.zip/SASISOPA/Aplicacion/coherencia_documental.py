"""Correcciones documentales reproducibles, sin modificar los PDF originales.

Se aplican al final del mismo render usado por vista previa y exportación.
Se conservan los años normativos de la fuente; su vigencia no se certifica.
"""
import re
import fitz
import coherencia_extra as extra

ROMANS=('I','II','III','IV','V','VI','VII','VIII','IX','X','XI','XII','XIII','XIV','XV','XVI','XVII','XVIII')
ELEMENTS=('Política','Identificación de peligros y evaluación de riesgos e impactos ambientales',
'Requisitos legales','Objetivos, metas e indicadores','Funciones, responsabilidades y autoridad',
'Competencia, capacitación y entrenamiento','Comunicación, participación y consulta',
'Control de documentos y registros','Mejores prácticas y estándares','Control de actividades y procesos',
'Integridad mecánica y aseguramiento de la calidad','Seguridad de contratistas',
'Preparación y respuesta a emergencias','Monitoreo, verificación y evaluación','Auditorías',
'Investigación de incidentes y accidentes','Revisión de resultados','Informes de desempeño')
# Corresponden a los entregables del tablero de origen, añadiendo los dos
# elementos omitidos. No son el número de anexos ni una evaluación realizada.
DELIVERABLES=(1,2,1,2,1,1,1,1,1,3,2,2,4,3,2,2,1,1)


def enabled(layout):
 return len(layout.get('pages',[]))>0 and any(p.get('slots') for p in layout['pages'])


LEGAL_KEY='dato.programa_legal'

def legal_rows(data):
 text=data.get('documents',{}).get('XIV',{}).get(LEGAL_KEY,'')
 rows=[]
 for index,line in enumerate(text.splitlines(),1):
  if not line.strip():continue
  row=[value.strip() for value in line.split('|')]
  if len(row)!=5:raise ValueError(f'Programa legal, línea {index}: usa cinco columnas separadas por | (requisito, aplicación, responsable, fecha y evidencia).')
  extra.validate_legal_date(row[3],index)
  rows.append(row)
 return rows

def extra_pages(data,doc_id):
 return (max(1,(len(legal_rows(data))+7)//8)+1) if doc_id=='XIV' else 1 if doc_id=='VIII' else 0


def _text(page,rect,value,write,fonts,size=9,align=0):
 if not page.rect.contains(fitz.Rect(rect)):raise ValueError('El texto debe quedar dentro de la página.')
 slot={'rect':list(rect),'font':'ArialMT','size':size,'min_size':size,'align':align}
 # El escritor rechaza desbordamientos; no recorta silenciosamente el texto.
 write(page,slot,value,fonts)


def _replace(page,rect,value,write,fonts,size=9,align=0):
 page.add_redact_annot(rect,fill=None,cross_out=False)
 page.apply_redactions(images=0,graphics=0)
 _text(page,rect,value,write,fonts,size,align)


def _revision(data,roman,resolve):
 return resolve(data,'documento.revision',roman) or ('0' if data.get('fresh_project') else '0')


def _code(data,roman,suffix,resolve):
 station=resolve(data,'estacion.numero',roman)
 return station+suffix+_revision(data,roman,resolve) if station else ''


def _normalize_norms(page,write,fonts):
 # Una coincidencia de número y organismo no autoriza cambiar la edición.
 # Conservar el año de la fuente y las actualizaciones capturadas; la vigencia
 # y aplicabilidad requieren revisión contra fuentes oficiales.
 return 0


def canonical_slot(slot,doc_id,index):
 if doc_id=='VIII' and index==15 and '.14.RE.03.R' in slot.get('default_text','') and 'no localizado' in slot['default_text']:
  slot={**slot,'default_text':LEGAL_NOTE}
 if not slot.get('code_suffix'):return slot
 slot=dict(slot)
 suffix=slot['code_suffix'].replace('.013.','.13.')
 suffix=re.sub(r'\.P[O0]\.1\.R$', '.PO.01.R', suffix)
 if doc_id=='VI' and index==44:suffix='.06.RE.11.R'
 slot['code_suffix']=suffix
 return slot


def apply(page,doc_id,index,data,layout,write,fonts,resolve):
 if not enabled(layout):return []
 notes=[]
 changes=_normalize_norms(page,write,fonts)
 for rect,text in NORM_PARAGRAPHS.get((doc_id,index),[]):_replace(page,rect,text,write,fonts,10)
 if changes:notes.append({'field':'coherencia.normas','count':changes,'status':'referencias_unificadas_vigencia_pendiente'})
 if doc_id=='VIII' and index in (10,11):
  for number,rect in MASTER[index]:
   roman=ROMANS[number-2] if number>1 else 'I'
   suffix='.MO.01.R' if number==1 else f'.{number-1:02d}.PO.01.R'
   value=_code(data,roman,suffix,resolve) if number>1 else (resolve(data,'estacion.numero','VIII')+suffix+(data.get('values',{}).get('documento.revision','').strip()or'0') if resolve(data,'estacion.numero','VIII') else '')
   _replace(page,rect,value,write,fonts,8)
  notes.append({'field':'coherencia.listado_maestro','rows':len(MASTER[index])})
 if doc_id=='VIII' and index in REGISTERS:
  for rect,suffix in REGISTERS[index]:
   roman=ROMANS[int(suffix.split('.')[1])-1]
   _replace(page,rect,_code(data,roman,suffix,resolve),write,fonts,8)
  notes.append({'field':'coherencia.indice_registros','rows':len(REGISTERS[index])})
 if doc_id=='VIII' and index==15:
  _replace(page,(35,588,560,602),'XIV .14.RE.03.R: formato integrado en el anexo final del procedimiento XIV; pendiente de completar y aprobar.',write,fonts,7)
 if doc_id=='VIII' and index==16:
  _text(page,(57,580,740,603),'Registros adicionales y procedimientos internos: ver complemento de control documental al final de este PDF.',write,fonts,8)
 if doc_id=='XVIII' and index==4:
  _replace(page,(226,333,534,612),'\n'.join(f'{r}. {t}' for r,t in zip(ROMANS,ELEMENTS)),write,fonts,10)
  # El tablero IED corresponde a XVIII, no al informe de revisión XVII.
  _replace(page,(222,638,535,677),'Llenar el tablero IED del registro '+_code(data,'XVIII','.18.RE.01.R',resolve)+' y comunicar los resultados aceptados.',write,fonts,9)
 if doc_id=='XVIII' and index==6:
  _performance_table(page,write,fonts)
 if doc_id=='XVIII' and index==7:
  _replace(page,(298,204,368,221),'>75% y <=95%',write,fonts,8,1)
  _replace(page,(65,248,540,292),'',write,fonts,9)
  page.draw_rect((65,248,540,292),fill=(1,1,1),color=None,overlay=True)
  _text(page,(65,248,540,292),'Cumplimiento de objetivos y metas (%) =\n(Objetivos y metas cumplidos / objetivos y metas establecidos) x 100',write,fonts,11)
  _text(page,(65,463,535,491),'Si el denominador es cero: No aplica; no asignar 0% ni 100%.\nEl mismo criterio aplica a capacitación y simulacros.',write,fonts,8)
 if doc_id=='IV' and index==8:
  for rect,text in INDICATORS:_replace(page,rect,text,write,fonts,8)
  _text(page,(72,465,734,497),'Metas de referencia: aprobar antes de programar. Comparar con un periodo base de igual duración y condiciones de operación.\nReducción (%) = (valor base - valor del periodo) / valor base x 100. Si la base es cero: No aplica; definir otro indicador.',write,fonts,8)
 if doc_id=='XIV' and index==9:
  _replace(page,(60,198,121,249),'Descarga de\naguas\nresiduales\nSSGA',write,fonts,8)
 if doc_id=='XIII' and index==8:
  _replace(page,(246,153,535,358),'Verificar la vulnerabilidad del entorno de la estación con información del sitio y fuentes competentes.\n\nGeológica: evaluar sismicidad, deslizamientos, hundimientos, derrumbes y actividad volcánica que puedan afectar la instalación.\n\nHidrometeorológica: evaluar lluvias, inundaciones, vientos y otros fenómenos aplicables a la ubicación. Considerar fenómenos costeros únicamente cuando correspondan.\n\nMedio natural: identificar flora, fauna y áreas sensibles del entorno real; no asumir características marinas en un sitio continental.',write,fonts,10)
 if doc_id=='XIII' and index==52:
  _replace(page,(99,472,533,670),
   'Ante sospecha de fractura, evitar movimientos innecesarios y activar el 911. No intentar acomodar el hueso.\n\nSi existe sangrado, seguir el apartado 9.7.10 de hemorragias de este mismo plan. No mantener instrucciones alternativas de presión indirecta o crioterapia.\n\nNo retirar objetos incrustados. La inmovilización y cualquier dispositivo de control de hemorragias deben ajustarse a la capacitación disponible y las indicaciones de emergencias.\n\nNo retrasar el auxilio para completar una inmovilización. Mover a la persona únicamente cuando resulte necesario para evitar un peligro inmediato, siguiendo indicaciones del servicio de emergencias.\n\nEl protocolo operativo debe aprobarlo el responsable de primeros auxilios.',write,fonts,10)
 if doc_id=='XIII' and index==61:
  _replace(page,(85,546,533,667),'La brigada se integra por personal designado y capacitado para las funciones asignadas, conforme al registro de brigadas y al plan aprobado de la estación.\n\nTodo el personal debe conocer la alarma, evacuación y comunicación de emergencias. Esto no lo convierte automáticamente en brigadista ni lo autoriza a realizar rescates, atención médica o combate de incendios fuera de su capacitación.\n\nActivar el 911 cuando corresponda y coordinarse con los servicios externos.',write,fonts,10)
 # Organización específica: no afirmar que existen cargos o recursos no verificados.
 if doc_id=='XIII' and index==63:
  _text(page,(85,644,533,677),'URE y COE: identificar en el plan aprobado a los responsables y sus equivalentes locales. No asumir personal, instalaciones o recursos sin verificar su disponibilidad.',write,fonts,8)
  regions=page.search_for('bombero medidor')
  if regions:
   rect=fitz.Rect(regions[0])
   for r in regions[1:]:rect|=r
   _replace(page,rect,'mando de apoyo',write,fonts,9)
 extra.apply(page,doc_id,index,data,write,fonts,resolve)
 return notes


def _performance_table(page,write,fonts):
 rect=fitz.Rect(56.96,218.29,566.41,641.44)
 page.add_redact_annot(rect+(.1,.1,-.1,-.1),fill=(1,1,1),cross_out=False)
 page.apply_redactions(images=0,graphics=0)
 page.draw_rect(rect,color=(1,1,1),fill=(1,1,1),width=0,overlay=True)
 xs=[rect.x0,99.3,311.9,439.3,rect.x1];height=rect.height/20
 rows=[('No.','Elemento','Entregables','Avance')]+[(r,t,str(n),'') for r,t,n in zip(ROMANS,ELEMENTS,DELIVERABLES)]+[('','Total',str(sum(DELIVERABLES)),'')]
 for i,row in enumerate(rows):
  y=rect.y0+i*height
  for col,value in enumerate(row):
   cell=fitz.Rect(xs[col],y,xs[col+1],y+height)
   page.draw_rect(cell,color=(.2,.2,.2),width=.4)
   if value:_text(page,cell+(2,1,-2,-1),value,write,fonts,7.5,0 if col==1 else 1)
 _text(page,(58,648,566,675),'Entregables de referencia: aprobar alcance y evidencias de cada elemento antes de evaluar.\nAvance = entregables aceptados / entregables requeridos x 100; no contar documentos sin evidencia.',write,fonts,8)


def append_legal_program(doc,data,write,fonts,resolve):
 rows=legal_rows(data)
 for offset in range(0,max(1,len(rows)),8):
  _legal_page(doc,data,rows[offset:offset+8],offset,write,fonts,resolve)


def _legal_page(doc,data,entries,offset,write,fonts,resolve):
 p=doc.new_page(width=792,height=612)
 _text(p,(35,25,755,50),'XIV. PROGRAMA DE EVALUACIÓN DEL CUMPLIMIENTO LEGAL',write,fonts,13,1)
 _text(p,(35,55,755,80),_code(data,'XIV','.14.RE.03.R',resolve),write,fonts,11,1)
 _text(p,(35,85,755,125),'Formato integrado para programación y seguimiento. No constituye evidencia de cumplimiento.\nCompletar y aprobar fechas, responsables, fuentes oficiales y aplicabilidad antes de su ejecución.',write,fonts,10)
 xs=[35,75,245,360,470,580,755];rows=9;h=34
 labels=['No.','Requisito / fuente oficial','Aplicabilidad','Responsable','Fecha prevista','Evidencia / resultado']
 for i in range(rows):
  for j in range(6):
   r=fitz.Rect(xs[j],140+i*h,xs[j+1],140+(i+1)*h);p.draw_rect(r,color=(.2,.2,.2),width=.5)
   t=labels[j] if i==0 else str(offset+i) if j==0 else entries[i-1][j-1] if i-1<len(entries) else ''
   if t:_text(p,r+(3,2,-3,-2),t,write,fonts,9)
 _text(p,(35,460,755,545),'Registrar la norma y su publicación oficial; verificar modificaciones, cancelaciones, entrada en vigor y obligaciones transitorias.\nEvaluar después de cambios aplicables y conforme al programa aprobado. No inferir cumplimiento a partir de una casilla vacía.\nResultado: Cumple / No cumple / No aplica (justificar), con evidencia verificable y acciones de seguimiento.\nElaboró: __________________  Revisó: __________________  Aprobó: __________________',write,fonts,10)


MASTER={10: [(1, (97.06399917602539, 291.9300079345703, 238.71750259399414, 328.45001220703125)),
      (2, (97.06399917602539, 330.45001220703125, 238.71750259399414, 354.24998474121094)),
      (3, (97.06399917602539, 356.24998474121094, 238.71750259399414, 405.3900146484375)),
      (4, (97.06399917602539, 407.3900146484375, 238.71750259399414, 431.1899871826172)),
      (5, (97.06399917602539, 433.1899871826172, 238.71750259399414, 469.58998107910156)),
      (6, (97.06399917602539, 471.58998107910156, 238.71750259399414, 508.02000427246094)),
      (7, (97.06399917602539, 510.02000427246094, 238.71750259399414, 546.5400390625)),
      (8, (97.06399917602539, 548.5400390625, 238.71750259399414, 584.9399719238281)),
      (9, (97.06399917602539, 586.9399719238281, 238.71750259399414, 623.4600219726562)),
      (10, (97.06399917602539, 625.4600219726562, 238.71750259399414, 661.8800048828125)),
      (11, (97.06399917602539, 663.8800048828125, 238.71750259399414, 700.2799987792969)),
      (12, (97.06399917602539, 702.2799987792969, 238.71750259399414, 751.434308733259))],
 11: [(13, (97.06399917602539, 154.22572544642858, 238.54200286865233, 178.05999755859375)),
      (14, (97.06399917602539, 180.05999755859375, 238.54200286865233, 216.489990234375)),
      (15, (97.06399917602539, 218.489990234375, 238.54200286865233, 254.8900146484375)),
      (16, (97.06399917602539, 256.8900146484375, 238.54200286865233, 280.6899871826172)),
      (17, (97.06399917602539, 282.6899871826172, 238.54200286865233, 319.21002197265625)),
      (18, (97.06399917602539, 321.21002197265625, 238.54200286865233, 345.00999450683594)),
      (19, (97.06399917602539, 347.00999450683594, 238.54200286865233, 370.8643014090402))]}

INDICATORS=[((309.8483238220215, 197.3000030517578, 421.1420135498047, 249.61000061035156),
  'Reducir 20% el volumen de descarga del SSGA'),
 ((526.8349853515625, 251.61000061035156, 617.9720153808594, 279.00999450683594),
  'Suma de residuos diarios'),
 ((309.8483238220215, 281.00999450683594, 421.1420135498047, 310.8099822998047),
  'Reducir permanencia en almacén conforme al programa'),
 ((425.1420135498047, 281.00999450683594, 522.8349853515625, 310.8099822998047), 'Días en almacén'),
 ((526.8349853515625, 281.00999450683594, 617.9720153808594, 310.8099822998047),
  'Fecha de retiro menos fecha de ingreso'),
 ((621.9720153808594, 281.00999450683594, 677.0324157714844, 310.8099822998047), 'Días'),
 ((309.8483238220215, 344.74998474121094, 421.1420135498047, 373.34999084472656),
  'Reducir 10% de energía consumida'),
 ((425.1420135498047, 344.74998474121094, 522.8349853515625, 373.34999084472656),
  'Energía consumida'),
 ((526.8349853515625, 344.74998474121094, 617.9720153808594, 373.34999084472656),
  'Lectura final menos inicial'),
 ((621.9720153808594, 344.74998474121094, 677.0324157714844, 373.34999084472656), 'kWh'),
 ((309.8483238220215, 375.34999084472656, 421.1420135498047, 419.0699920654297),
  'Reducir 50% el consumo respecto de la base'),
 ((526.8349853515625, 375.34999084472656, 617.9720153808594, 419.0699920654297),
  'Masa de producto consumido'),
 ((193.7563934326172, 421.0699920654297, 305.8483238220215, 459.8999938964844),
  'Reducir consumo de agua'),
 ((309.8483238220215, 421.0699920654297, 421.1420135498047, 459.8999938964844),
  'Reducir 10% del consumo de agua')]

# Se sustituyen también los textos de requisitos: cambiar solo el año dejaría
# títulos antiguos unidos a identificadores diferentes. Los temas se expresan
# como descripción, sin atribuirles un título oficial no comprobado.
_EPP='Dotar al personal del equipo de protección personal seleccionado mediante evaluación de riesgos y conforme a los requisitos aplicables. La referencia NOM-017-STPS-2008 es histórica del expediente; verificar su sustitución, vigencia y obligaciones transitorias en la fuente oficial antes de aprobar la selección. Un proyecto de norma no se tratará como una NOM vigente.'
_ELECTRIC='En áreas clasificadas, utilizar equipos, accesorios y conexiones eléctricas adecuados para esa clasificación, y mantener su puesta a tierra. Referencias del expediente: NOM-001-SEDE-2012 y NOM-029-STPS-2011. Verificar vigencia, aplicabilidad y requisitos de instalación y mantenimiento con el responsable competente antes de autorizar trabajos.'
_HDS='Entregar la composición química y las hojas de datos de seguridad de las sustancias peligrosas suministradas. Usar el sistema armonizado de identificación y comunicación de peligros referido en NOM-018-STPS-2015, previa verificación de vigencia y aplicabilidad. Mantener la información accesible y actualizada para el personal expuesto.'
_LABEL='Identificar de manera legible y durable los productos, sustancias químicas peligrosas y equipos suministrados, conforme al contrato y los requisitos aplicables. Mantener coherencia entre etiquetas y hojas de datos de seguridad. Referencias del expediente: NOM-018-STPS-2015, NOM-005-STPS-1998 y NOM-010-STPS-2014; verificar vigencia y aplicabilidad antes de aprobar. La evaluación de exposición a agentes químicos debe documentarse; no se presume por disponer de una etiqueta.'
NORM_PARAGRAPHS={
 ('XII',19):[((85,318,532,376),'6.8.1. '+_EPP)],
 ('XII',21):[((85,177,532,250),'6.10.4. '+_ELECTRIC)],
 ('XII',22):[((85,258,532,331),'6.11.6. '+_HDS),((85,339,532,499),'6.11.7. '+_LABEL)],
 ('XII',33):[((132,584,456,670),_EPP)],
 ('XII',35):[((132,418,459,516),_ELECTRIC)],
 ('XII',36):[((132,473,456,584),_HDS),((132,584,456,751),_LABEL)],
 ('XII',37):[((132,153,459,222),'Continuación del requisito 4.11.7: verificar los requisitos de exposición a agentes químicos de NOM-010-STPS-2014 con la fuente oficial y conservar las evidencias de evaluación que correspondan. No utilizar como vigente una referencia histórica sin comprobarla.')],
}


REGISTERS={13: [((224.61000061035156, 182.43999481201172, 350.4045618230646, 193.5599822998047),
       '.01.RE.01.R'),
      ((224.61000061035156, 194.5599822998047, 350.4045618230646, 205.58998107910156),
       '.01.RE.02.R'),
      ((224.61000061035156, 206.58998107910156, 350.4045618230646, 229.11000061035156),
       '.01.RE.03.R'),
      ((224.61000061035156, 230.11000061035156, 350.4045618230646, 241.11000061035156),
       '.02.RE.01.R'),
      ((224.61000061035156, 242.11000061035156, 350.4045618230646, 264.62998962402344),
       '.02.RE.02.R'),
      ((224.61000061035156, 265.62998962402344, 350.4045618230646, 288.0299835205078),
       '.02.RE.03.R'),
      ((224.61000061035156, 289.0299835205078, 350.4045618230646, 300.0299835205078),
       '.02.RE.04.R'),
      ((224.61000061035156, 301.0299835205078, 350.4045618230646, 323.5500183105469),
       '.02.RE.05.R'),
      ((224.61000061035156, 324.5500183105469, 350.4045618230646, 347.08998107910156),
       '.03.RE.01.R'),
      ((224.61000061035156, 348.08998107910156, 350.4045618230646, 382.12998962402344),
       '.03.RE.02.R'),
      ((224.61000061035156, 383.12998962402344, 350.4045618230646, 417.04998779296875),
       '.03.RE.03.R'),
      ((224.61000061035156, 418.04998779296875, 350.4045618230646, 440.5699920654297),
       '.04.RE.01.R'),
      ((224.61000061035156, 441.5699920654297, 350.4045618230646, 464.0899963378906),
       '.04.RE.02.R'),
      ((224.61000061035156, 465.0899963378906, 350.4045618230646, 487.63999938964844),
       '.05.RE.01.R'),
      ((224.61000061035156, 488.63999938964844, 350.4045618230646, 499.63999938964844),
       '.05.RE.02.R'),
      ((224.61000061035156, 500.63999938964844, 350.4045618230646, 523.156005859375),
       '.05.RE.03.R'),
      ((224.61000061035156, 524.156005859375, 350.4045618230646, 535.156005859375), '.06.RE.01.R'),
      ((224.61000061035156, 536.156005859375, 350.4045618230646, 547.156005859375), '.06.RE.02.R'),
      ((224.61000061035156, 548.156005859375, 350.4045618230646, 559.1860046386719),
       '.06.RE.03.R')],
 14: [((224.61000061035156, 153.72999382019043, 350.41001892089844, 176.1599884033203),
       '.06.RE.04.R'),
      ((224.61000061035156, 177.1599884033203, 350.41001892089844, 188.1599884033203),
       '.06.RE.05.R'),
      ((224.61000061035156, 189.1599884033203, 350.41001892089844, 211.7100067138672),
       '.06.RE.06.R'),
      ((224.61000061035156, 212.7100067138672, 350.41001892089844, 246.74998474121094),
       '.06.RE.07.R'),
      ((224.61000061035156, 247.74998474121094, 350.41001892089844, 281.7899932861328),
       '.06.RE.08.R'),
      ((224.61000061035156, 282.7899932861328, 350.41001892089844, 305.1899871826172),
       '.06.RE.09.R'),
      ((224.61000061035156, 306.1899871826172, 350.41001892089844, 328.71002197265625),
       '.07.RE.01.R'),
      ((224.61000061035156, 329.71002197265625, 350.41001892089844, 340.71002197265625),
       '.07.RE.02.R'),
      ((224.61000061035156, 341.71002197265625, 350.41001892089844, 364.25), '.07.RE.03.R'),
      ((224.61000061035156, 365.25, 350.41001892089844, 387.77001953125), '.08.RE.01.R'),
      ((224.61000061035156, 388.77001953125, 350.41001892089844, 399.77001953125), '.08.RE.02.R'),
      ((224.61000061035156, 400.77001953125, 350.41001892089844, 411.77001953125), '.08.RE.03.R'),
      ((224.61000061035156, 412.77001953125, 350.41001892089844, 423.77001953125), '.08.RE.04.R'),
      ((224.61000061035156, 424.77001953125, 350.41001892089844, 435.77001953125), '.09.RE.01.R'),
      ((224.61000061035156, 436.77001953125, 350.41001892089844, 447.77001953125), '.09.RE.02.R'),
      ((224.61000061035156, 448.77001953125, 350.41001892089844, 528.7960205078125), '.09.RE.03.R'),
      ((224.61000061035156, 529.7960205078125, 350.41001892089844, 540.7960205078125),
       '.10.RE.01.R'),
      ((224.61000061035156, 541.7960205078125, 350.41001892089844, 552.7960205078125),
       '.10.RE.02.R'),
      ((224.61000061035156, 553.7960205078125, 350.41001892089844, 564.8260192871094),
       '.11.RE.01.R')],
 15: [((224.61000061035156, 153.72999382019043, 350.41001892089844, 176.1599884033203),
       '.11.RE.02.R'),
      ((224.61000061035156, 177.1599884033203, 350.41001892089844, 199.6800079345703),
       '.11.RE.03.R'),
      ((224.61000061035156, 200.6800079345703, 350.41001892089844, 211.7100067138672),
       '.12.RE.01.R'),
      ((224.61000061035156, 212.7100067138672, 350.41001892089844, 235.22999572753906),
       '.12.RE.02.R'),
      ((224.61000061035156, 236.22999572753906, 350.41001892089844, 270.27001953125),
       '.12.RE.03.R'),
      ((224.61000061035156, 271.27001953125, 350.41001892089844, 282.27001953125), '.12.RE.04.R'),
      ((224.61000061035156, 283.27001953125, 350.41001892089844, 305.7899932861328), '.12.RE.05.R'),
      ((224.61000061035156, 306.7899932861328, 350.41001892089844, 317.7899932861328),
       '.13.RE.01.R'),
      ((224.61000061035156, 318.7899932861328, 350.41001892089844, 329.7899932861328),
       '.13.RE.02.R'),
      ((224.61000061035156, 330.7899932861328, 350.41001892089844, 353.21002197265625),
       '.13.RE.03.R'),
      ((224.61000061035156, 354.21002197265625, 350.41001892089844, 365.21002197265625),
       '.13.RE.04.R'),
      ((224.61000061035156, 366.21002197265625, 350.41001892089844, 377.21002197265625),
       '.14.RE.01.R'),
      ((224.61000061035156, 378.21002197265625, 350.41001892089844, 412.25), '.14.RE.02.R'),
      ((224.61000061035156, 413.25, 350.41001892089844, 447.2899932861328), '.14.RE.03.R'),
      ((224.61000061035156, 448.2899932861328, 350.41001892089844, 470.6899871826172),
       '.14.RE.04.R'),
      ((224.61000061035156, 471.6899871826172, 350.41001892089844, 482.72003173828125),
       '.15.RE.01.R'),
      ((224.61000061035156, 483.72003173828125, 350.41001892089844, 494.7200012207031),
       '.15.RE.02.R'),
      ((224.61000061035156, 495.7200012207031, 350.41001892089844, 506.7200012207031),
       '.15.RE.03.R'),
      ((224.61000061035156, 507.7200012207031, 350.41001892089844, 518.7160034179688),
       '.15.RE.04.R'),
      ((224.61000061035156, 519.7160034179688, 350.41001892089844, 530.7160034179688),
       '.15.RE.05.R'),
      ((224.61000061035156, 531.7160034179688, 350.41001892089844, 542.7160034179688),
       '.15.RE.06.R'),
      ((224.61000061035156, 543.7160034179688, 350.41001892089844, 566.2660217285156),
       '.15.RE.07.R')],
 16: [((224.61000061035156, 153.72999382019043, 350.41001892089844, 164.75999450683594),
       '.15.RE.08.R'),
      ((224.61000061035156, 165.75999450683594, 350.41001892089844, 188.1599884033203),
       '.15.RE.09.R'),
      ((224.61000061035156, 189.1599884033203, 350.41001892089844, 200.1599884033203),
       '.15.RE.10.R'),
      ((224.61000061035156, 201.1599884033203, 350.41001892089844, 223.7100067138672),
       '.15.RE.11.R'),
      ((224.61000061035156, 224.7100067138672, 350.41001892089844, 247.22999572753906),
       '.16.RE.01.R'),
      ((224.61000061035156, 248.22999572753906, 350.41001892089844, 270.74998474121094),
       '.16.RE.02.R'),
      ((224.61000061035156, 271.74998474121094, 350.41001892089844, 282.74998474121094),
       '.17.RE.01.R'),
      ((224.61000061035156, 283.74998474121094, 350.41001892089844, 306.3000183105469),
       '.18.RE.01.R')]}


def append_annexes(doc,doc_id,data,write,fonts,resolve):
 if doc_id=='VIII':extra.append_control(doc,data,write,fonts,resolve)
 elif doc_id=='XIV':
  append_legal_program(doc,data,write,fonts,resolve)
  extra.append_followup(doc,data,write,fonts,resolve)


LEGAL_NOTE="XIV .14.RE.03.R: formato integrado en el anexo final del procedimiento XIV; pendiente de completar y aprobar."

def upgrade_project(data):
 if not isinstance(data,dict):return data
 bindings=data.get('bindings',[])
 for binding in bindings if isinstance(bindings,list) else []:
  if not isinstance(binding,dict):continue
  if binding.get("doc")=="VIII" and binding.get("page")==15 and ".14.RE.03.R"in binding.get("default_text","") and "no localizado"in binding["default_text"]:binding["default_text"]=LEGAL_NOTE
 documents=data.get('documents',{})
 stores=[data.get('values',{})]+(list(documents.values())if isinstance(documents,dict)else[])
 defaults=data.get('defaults')or{}
 if isinstance(defaults,dict):
  documents=defaults.get('documents',{})
  stores.extend([defaults.get('values',{})]+(list(documents.values())if isinstance(documents,dict)else[]))
 old='XIV .14.RE.03.R: formato no localizado; entrega e integración pendientes, no registro disponible.'
 for store in stores:
  if not isinstance(store,dict):continue
  for key,value in list(store.items()):
   if isinstance(key,str)and key.startswith('dato.')and value==old:store[key]=LEGAL_NOTE
 return data
