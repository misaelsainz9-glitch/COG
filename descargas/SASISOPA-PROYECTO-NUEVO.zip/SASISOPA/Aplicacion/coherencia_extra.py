"""Cierre de los hallazgos de la segunda auditoría documental."""
from datetime import datetime
import re
import fitz

FIELDS={
 'IV': [('dato.meta_descargas','Meta de descargas SSGA'),('dato.meta_rsu','Meta de residuos sólidos urbanos'),('dato.meta_rp','Meta de residuos peligrosos'),('dato.meta_energia','Meta de consumo de energía'),('dato.meta_agua','Meta de consumo de agua'),('dato.meta_limpieza','Meta de productos de limpieza'),('dato.meta_fugas','Meta de fugas')],
 'VI':[('dato.proveedor_capacitacion','Proveedor de capacitación'),('dato.horario_capacitacion','Horario de capacitación'),('dato.transportista_valores','Transportista autorizado de valores')],
 'XIII':[('dato.directorio_emergencias','Contactos de emergencia verificados (además del 911)')],
}
GOALS={
 'dato.meta_descargas':'Reducir 20% el volumen de descarga del SSGA',
 'dato.meta_rsu':'Disminuir 30% la generación de RSU',
 'dato.meta_rp':'Reducir permanencia en almacén conforme al programa',
 'dato.meta_energia':'Reducir 10% de energía consumida',
 'dato.meta_agua':'Reducir 10% del consumo de agua',
 'dato.meta_limpieza':'Reducir 50% el consumo respecto de la base',
 'dato.meta_fugas':'Cero fugas',
}
INTERNALS=[('II','.02.PO.02.R','Identificación de peligros y evaluación de riesgos'),
 ('XI','.11.PO.02.R','Mantenimiento de la estación'),('XII','.12.PO.02.R','Requisitos de seguridad para contratistas'),
 ('XIII','.13.PO.02.R','Planes de atención y respuesta a emergencias'),
 ('XIV','.14.PO.02.R','Calibración, verificación y mantenimiento de equipos'),
 ('XIV','.14.PO.03.R','Evaluación del cumplimiento de requisitos legales'),
 ('XIV','.14.PO.04.R','Administración de hallazgos del monitoreo'),
 ('XVI','.16.PO.02.R','Investigación de causa raíz')]
VI_RECORDS=[('.06.RE.10.R','Plan de sesión'),('.06.RE.11.R','Formación en prevención de riesgos y emergencias'),
 ('.06.RE.12.R','Criterios de competencia del RT y equipo'),('.06.RE.13.R','Programa anual de desarrollo de competencia')]


def validate_legal_date(value,index):
 if not value or value.casefold() in ('pendiente','por definir','por programar','no aplica','n/a'):return
 try:
  if not re.fullmatch(r'\d{2}/\d{2}/\d{4}',value):raise ValueError()
  datetime.strptime(value,'%d/%m/%Y')
 except ValueError:raise ValueError(f'Programa legal, línea {index}: la fecha prevista debe ser real y usar dd/mm/aaaa, o indicar Pendiente.') from None


GOAL_RECTS={'dato.meta_energia':(309.85,344.75,421.14,373.35),'dato.meta_agua':(309.85,421.07,421.14,459.90),'dato.meta_limpieza':(309.85,375.35,421.14,419.07),'dato.meta_fugas':(309.85,312.81,421.14,342.75)}
GOAL_RECTS.update({'dato.meta_descargas':(309.85,197,421.14,249.5),'dato.meta_rsu':(309.85,250.5,421.14,280.5),'dato.meta_rp':(309.85,281.5,421.14,312)})

def goal(data,key,resolve):
 target=fitz.Rect(GOAL_RECTS[key])
 for binding in reversed(data.get('bindings',[])):
  if binding.get('doc')!='IV' or binding.get('page')!=8 or not binding.get('key','').startswith('dato.') or not binding.get('editable',True):continue
  overlap=target & fitz.Rect(binding['rect'])
  if overlap.get_area()<target.get_area()*.25:continue
  value=resolve(data,binding['key'],'IV')
  if value:return value
 return resolve(data,key,'IV') or GOALS[key]


def apply(page,roman,index,data,write,fonts,resolve):
 from coherencia_documental import _replace,_text
 # Cambiar solamente el glifo cero: no borrar el resto del renglón ni
 # los números de estación que el usuario ya capturó entre sus fragmentos.
 edits=[]
 for block in page.get_text('rawdict')['blocks']:
  for line in block.get('lines',[]):
   for span in line['spans']:
    chars=span['chars'];text=''.join(ch['c']for ch in chars)
    for match in re.finditer(r'(?<=\.)P0(?=\s*\.)',text):edits.append((span,chars[match.start()+1]))
 for span,char in edits:
  rect=fitz.Rect(char['bbox']);font,_,_=fonts.get(span['font'],'O')
  scale=min(1,rect.width/max(.001,font.text_length('O',fontsize=span['size'])))
  page.add_redact_annot(rect+(.1,.1,-.1,-.1),fill=None,cross_out=False);page.apply_redactions(images=0,graphics=0)
  write(page,{'rect':list(rect),'font':span['font'],'size':span['size'],'min_size':span['size'],'baseline':char['origin'][1],'x_scale':scale},'O',fonts)
 if roman=='IV'and index==8:
  for key in ('dato.meta_descargas','dato.meta_rsu','dato.meta_rp'):
   _replace(page,GOAL_RECTS[key],goal(data,key,resolve),write,fonts,8)
  _replace(page,(309.85,344.75,421.14,373.35),goal(data,'dato.meta_energia',resolve),write,fonts,8)
  _replace(page,(309.85,375.35,421.14,419.07),goal(data,'dato.meta_limpieza',resolve),write,fonts,8)
  _replace(page,(309.85,421.07,421.14,459.90),goal(data,'dato.meta_agua',resolve),write,fonts,8)
  _replace(page,(309.85,312.81,421.14,342.75),goal(data,'dato.meta_fugas',resolve),write,fonts,8)
 if roman=='VI'and index in PROVIDERS:
  value=resolve(data,'dato.proveedor_capacitacion','VI') or 'Por designar'
  for rect in PROVIDERS[index]:_replace(page,rect,value,write,fonts,8,1)
  value=resolve(data,'dato.horario_capacitacion','VI') or 'Por programar'
  for rect in HOURS[index]:
   r=fitz.Rect(rect);r.x0,r.x1=(518,586) if index==42 else (444,549)
   _replace(page,r,value,write,fonts,8,1)
 if roman=='VI'and index==23:
  _replace(page,(200,497,550,512),'Entrega de valores: '+(resolve(data,'dato.transportista_valores','VI') or 'transportista autorizado por designar')+'.',write,fonts,9)
 if roman=='IX'and index==10:
  regions=page.search_for('CONTROL DE ACTUALIZACIÓN DE LA POLITICA:')
  if regions:
   rect=fitz.Rect(regions[0]);rect.x1=550
   _replace(page,rect,'CONTROL DE ACTUALIZACIÓN DE BUENAS PRÁCTICAS:',write,fonts,9)
 if roman=='XI'and index==13:
  _replace(page,(664,198.1,768,215.7),'Visual: mensual / Servicio: anual',write,fonts,7,1)
 if roman=='XIV'and index==9:
  for key,rect in [('dato.meta_descargas',(124,195,210,249)),('dato.meta_rsu',(124,250,210,304)),('dato.meta_rp',(124,305,210,359))]:
   _replace(page,rect,goal(data,key,resolve),write,fonts,8)
 if roman=='XIII'and index==36:
  _replace(page,(85,438,533,482),'Las tablas siguientes son referencias para revisar con el responsable del estudio. No acreditan una clasificación realizada ni aprobada para esta estación.',write,fonts,10)
  for rect,text in FREQUENCY_EDITS:_replace(page,rect,text,write,fonts,8)
  _text(page,(85,637,533,669),'T: intervalo estimado entre eventos, en años. Límites propuestos, pendientes de aprobación técnica.\nPara T > 10, aprobar criterios de categorías 2 y 1; la falta de registros no prueba baja frecuencia.',write,fonts,8)
 if roman=='XIV'and index==7:
  # Referencia no aplicable al sitio continental; conservar el resto de la oración.
  for rect in page.search_for('zona costera'):_replace(page,rect,'zona del sitio',write,fonts,9)
 if roman=='XIII'and index==49:
  for line in page.get_text('dict')['blocks']:
   for spanline in line.get('lines',[]):
    text=''.join(s['text']for s in spanline['spans'])
    if 'Tenga en mente que en la empresa labora personal' in text:
     y=spanline['bbox'][1];_replace(page,(102,y,532,y+28),'Coordinar la atención con las autoridades y con el personal efectivamente designado y capacitado en el plan.',write,fonts,10)
 if roman=='XIII'and index==50:
  _replace(page,(102,201,533,273),'Ante una amenaza, alejarse del objeto sin tocarlo y activar el 911 desde un lugar seguro. Seguir las instrucciones de las autoridades.\n'+(resolve(data,'dato.directorio_emergencias','XIII') or 'Integrar y verificar el directorio local de protección civil, bomberos, atención médica y responsables de la estación. Registrar fuente y fecha de comprobación.'),write,fonts,10)
  _replace(page,(84,325,533,671),
   '9.7.1 Convulsiones: actuación inicial\n\nTomar el tiempo, retirar objetos que puedan lesionar y proteger la cabeza sin sujetar a la persona. No introducir objetos ni dedos en la boca. No dar alimentos, líquidos ni medicamentos por boca durante la crisis o mientras no esté plenamente alerta.\n\nActivar el 911 si la crisis dura cinco minutos o más, si se repite sin recuperación, si es la primera conocida, hay lesión, dificultad para respirar, embarazo o cualquier otra situación preocupante. No esperar quince minutos para solicitar ayuda.\n\nAl terminar, comprobar respuesta y respiración, permanecer con la persona y seguir las indicaciones del servicio de emergencias. Si no respira normalmente, solicitar instrucciones e iniciar las maniobras que correspondan a la capacitación disponible.\n\nRegistrar lo observado para entregarlo al personal sanitario. Estas indicaciones generales requieren integrarse al protocolo de primeros auxilios y aprobarse por el responsable competente antes del uso operativo.',write,fonts,10)
 if roman=='XIII'and index in RISK_EDITS:
  for rect,value in RISK_EDITS[index]:_replace(page,rect,value,write,fonts,9,1)
  if index in (37,38):_text(page,(57,600,556,652),'CRITERIOS DE REFERENCIA: límites documentales sin solapamiento. El responsable del estudio debe aprobar su aplicabilidad antes de clasificar riesgos. No se recalcula ni acredita un análisis de esta estación.',write,fonts,8)


def append_control(doc,data,write,fonts,resolve):
 from coherencia_documental import _text,_code
 p=doc.new_page(width=792,height=612)
 _text(p,(35,25,755,55),'VIII. COMPLEMENTO DE CONTROL DOCUMENTAL',write,fonts,13,1)
 _text(p,(35,60,755,100),'Complementa el listado maestro y el índice de registros del mismo procedimiento.\nSe conservan los identificadores existentes; cada revisión sigue al documento correspondiente.',write,fonts,10)
 rows=[('Listado maestro: procedimientos internos','Código / revisión')]+[(name,_code(data,r,s,resolve))for r,s,name in INTERNALS]+[('Índice: registros adicionales de VI','Código / revisión')]+[(name,_code(data,'VI',s,resolve))for s,name in VI_RECORDS]
 for i,(name,code)in enumerate(rows):
  y=115+i*29
  for a,b,text in [(35,505,name),(505,755,code)]:
   rect=fitz.Rect(a,y,b,y+29);p.draw_rect(rect,color=(.2,.2,.2),width=.4);_text(p,rect+(4,2,-4,-2),text,write,fonts,9)
 _text(p,(35,535,755,582),'Archivo, respaldo, acceso y retención: aplicar los controles aprobados del procedimiento VIII y su índice.\nEste complemento no acredita aprobaciones o ejecución; completar la evidencia y los responsables que correspondan.',write,fonts,9)


def append_followup(doc,data,write,fonts,resolve):
 from coherencia_documental import _text,_code
 from calendarios import period,MONTHS
 p=doc.new_page(width=792,height=612)
 _text(p,(35,25,755,55),'XIV. SEGUIMIENTO Y MEDICIÓN: CONTINUACIÓN',write,fonts,13,1)
 _text(p,(35,60,755,85),_code(data,'XIV','.14.RE.01.R',resolve),write,fonts,10,1)
 _text(p,(35,90,755,130),'Complementa los tres aspectos del programa original con los cuatro restantes de IV.\nLas metas son referencias o datos capturados; confirmar aplicabilidad, responsables y evidencia antes de aprobar.',write,fonts,10)
 months=period(data);labels=[MONTHS[m-1]for y,m in months]if months else ['Mes '+str(i+1)for i in range(12)]
 xs=[35,135,285,395,465]+[465+(755-465)*i/12 for i in range(1,13)]
 headers=['Aspecto','Meta','Responsable','Captura']+labels
 person=resolve(data,'rol.encargado_estacion.nombre','XIV')or'Por asignar'
 entries=[('Energía','dato.meta_energia','Bimestral'),('Consumo de agua','dato.meta_agua','Diaria'),('Limpieza','dato.meta_limpieza','Diaria'),('Fugas','dato.meta_fugas','Diaria')]
 for row in range(5):
  y=145+row*62
  texts=headers if row==0 else [entries[row-1][0],goal(data,entries[row-1][1],resolve),person,entries[row-1][2]]+['']*12
  for col,text in enumerate(texts):
   rect=fitz.Rect(xs[col],y,xs[col+1],y+62);p.draw_rect(rect,color=(.2,.2,.2),width=.4)
   if text:_text(p,rect+(2,2,-2,-2),text,write,fonts,7.5)
 if months:_text(p,(35,465,755,487),'Periodo: '+f'{months[0][0]:04d}-{months[0][1]:02d} a {months[-1][0]:04d}-{months[-1][1]:02d}',write,fonts,9)
 _text(p,(35,490,755,560),'Registrar programación y ejecución con evidencia, sin dar por realizadas las actividades de meses vacíos.\nMedir energía en kWh, agua en m3, limpieza en kg y fugas en eventos. Usar el periodo base aprobado de IV.\nResponsables y frecuencias deben verificarse contra la operación real; los nombres capturados no acreditan competencia.',write,fonts,9)


PROVIDERS={42: [(235.1300048828125, 217.39619140625, 421.053466796875, 240.42160339355468),
      (235.1300048828125, 244.63621215820314, 421.053466796875, 267.66160888671874),
      (235.1300048828125, 268.156201171875, 421.053466796875, 291.18162841796874),
      (235.1300048828125, 291.676220703125, 421.053466796875, 314.5816223144531),
      (235.1300048828125, 326.59620361328126, 421.053466796875, 349.64161987304686),
      (235.1300048828125, 350.13621215820314, 421.053466796875, 373.16160888671874),
      (235.1300048828125, 391.89619140625, 421.053466796875, 414.92161865234374),
      (235.1300048828125, 419.13621215820314, 421.053466796875, 442.16160888671874),
      (235.1300048828125, 454.176220703125, 421.053466796875, 477.081591796875),
      (235.1300048828125, 489.12620239257814, 421.053466796875, 512.1515991210938)],
 43: [(236.3300018310547, 179.4462097167969, 332.89227294921875, 213.90158386230468),
      (236.3300018310547, 226.87620239257814, 332.89227294921875, 261.30162353515624),
      (236.3300018310547, 262.51621704101564, 332.89227294921875, 296.9416076660156),
      (236.3300018310547, 298.156201171875, 332.89227294921875, 332.7016174316406),
      (236.3300018310547, 333.21619873046876, 332.89227294921875, 367.64161987304686)]}


HOURS={42: [(522.5800170898438, 216.59619140625, 559.6710205078125, 229.7015838623047),
      (522.5800170898438, 243.83621215820312, 559.6710205078125, 256.9416046142578),
      (522.5800170898438, 267.356201171875, 559.6710205078125, 280.46160888671875),
      (522.5800170898438, 290.876220703125, 559.6710205078125, 303.98162841796875),
      (522.5800170898438, 325.79620361328125, 559.6710205078125, 338.901611328125),
      (522.5800170898438, 349.3362121582031, 559.6710205078125, 362.4416198730469),
      (522.5800170898438, 391.09619140625, 559.6710205078125, 404.20159912109375),
      (522.5800170898438, 418.3362121582031, 559.6710205078125, 431.4416198730469),
      (522.5800170898438, 453.376220703125, 559.6710205078125, 466.48162841796875),
      (522.5800170898438, 488.3262023925781, 559.6710205078125, 501.4316101074219)],
 43: [(448.8699951171875, 178.64620971679688, 485.9610595703125, 191.75160217285156),
      (448.8699951171875, 226.07620239257812, 485.9610595703125, 239.1815948486328),
      (448.8699951171875, 261.7162170410156, 485.9610595703125, 274.8216247558594),
      (448.8699951171875, 297.356201171875, 485.9610595703125, 310.46160888671875),
      (448.8699951171875, 332.41619873046875, 485.9610595703125, 345.5216064453125)]}


RISK_EDITS={37: [((427.30999755859375, 236.35859026227678, 487.1390024820964, 340.1700134277344),
       'L > 50\n(millones USD)'),
      ((491.1390024820964, 236.35859026227678, 556.8976619944852, 340.1700134277344),
       'L > 50\n(millones USD)'),
      ((320.9700012207031, 236.35859026227678, 423.30999755859375, 340.1700134277344),
       'Control en más de 7 días'),
      ((427.30999755859375, 344.1700134277344, 487.1390024820964, 455.8699951171875),
       '15 < L <= 50\n(millones USD)'),
      ((491.1390024820964, 344.1700134277344, 556.8976619944852, 455.8699951171875),
       '15 < L <= 50\n(millones USD)'),
      ((320.9700012207031, 344.1700134277344, 423.30999755859375, 455.8699951171875),
       'Control en más de 24 horas y hasta 7 días'),
      ((220.97350025177002, 344.1700134277344, 316.9700012207031, 455.8699951171875),
       'De 16 a 100 fatalidades'),
      ((427.30999755859375, 459.8699951171875, 487.1390024820964, 571.7342703683036),
       '5 < L <= 15\n(millones USD)'),
      ((491.1390024820964, 459.8699951171875, 556.8976619944852, 571.7342703683036),
       '5 < L <= 15\n(millones USD)'),
      ((320.9700012207031, 459.8699951171875, 423.30999755859375, 571.7342703683036),
       'Control en más de 6 y hasta 24 horas'),
      ((220.97350025177002, 459.8699951171875, 316.9700012207031, 571.7342703683036),
       'De 4 a 15 fatalidades'),
      ((129.620667775472, 459.8699951171875, 216.97350025177002, 571.7342703683036), 'De 1 a 3 fatalidades')],
 38: [((427.34999084472656, 155.8699951171875, 487.2200012207031, 324.9300079345703),
       '0.500 < L <= 5\n(millones USD)'),
      ((491.2200012207031, 155.8699951171875, 557.50400390625, 324.9300079345703),
       '0.500 < L <= 5\n(millones USD)'),
      ((321.00999450683594, 155.8699951171875, 423.34999084472656, 324.9300079345703),
       'Control en más de 1 y hasta 6 horas'),
      ((427.34999084472656, 328.9300079345703, 487.2200012207031, 570.4142630440848),
       '0.250 < L <= 0.500\n(millones USD)'),
      ((491.2200012207031, 328.9300079345703, 557.50400390625, 570.4142630440848),
       '0.250 < L <= 0.500\n(millones USD)'),
      ((321.00999450683594, 328.9300079345703, 423.34999084472656, 570.4142630440848),
       'Control en hasta 1 hora')],
 39: [((427.34999084472656, 155.8699951171875, 487.2200012207031, 281.88427734375),
       '0 <= L <= 0.250\n(millones USD)'),
      ((491.2200012207031, 155.8699951171875, 557.433336046007, 281.88427734375),
       '0 <= L <= 0.250\n(millones USD)'),
      ((321.00999450683594, 155.8699951171875, 423.34999084472656, 281.88427734375), 'Sin fuga o derrame')]}

# Se aclaran los límites ya presentes sin inventar una vida útil ni una
# frecuencia para las categorías cualitativas de la fuente.
FREQUENCY_EDITS=[
 ((252,505,531,520),'0 < T <= 1 año'),
 ((252,520,531,535),'1 < T <= 3 años'),
 ((252,535,531,550),'3 < T <= 5 años'),
 ((252,550,531,565),'5 < T <= 10 años'),
 ((252,565,531,593),'Pendiente: aprobar intervalo y vida útil.\nNo asignar categoría 2 sin criterio aprobado.'),
 ((252,594,531,623),'Pendiente: aprobar estimación de frecuencia.\nSin registros no basta para asignar categoría 1.'),
]
