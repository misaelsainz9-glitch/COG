"""Per-user installation of the current source and private clean templates.

Python is bootstrapped by the signed python.org installer in the PS wrapper.
Activation occurs only after the application passes its Windows smoke check.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import sys
import uuid
from version_app import VERSION

RULES = ('revision_inheritance', 'shared_environmental_goals',
         'normative_years_preserved', 'risk_criteria_pending_approval')
REQUIRED = {'sasisopa18.py', 'editor_sasisopa.py', 'rutas_app.py', 'version_app.py',
            'lanzamiento.py', 'comprobacion_instalacion.py', 'requirements.txt',
            'catalogo18.json', 'assets/logo-pemex.png'}


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def write_atomic(path, text):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    try:
        if isinstance(text, bytes):
            temporary.write_bytes(text)
        else:
            temporary.write_text(text, encoding='utf-8', newline='')
        temporary.replace(path)
    finally:
        temporary.unlink(missing_ok=True)


def verify_payload(payload):
    payload = Path(payload).resolve()
    manifest = read_json(payload / 'manifest-usuario.json')
    files = manifest.get('files')
    if manifest.get('version') != VERSION or not isinstance(files, dict) or not REQUIRED <= files.keys():
        raise ValueError('El paquete esta incompleto o no corresponde a esta version.')
    if len(files) > 500:
        raise ValueError('El manifiesto contiene demasiados archivos.')
    seen = set()
    for name, expected in files.items():
        if not isinstance(name, str) or not isinstance(expected, str):
            raise ValueError('Manifiesto de archivos invalido.')
        relative = PurePosixPath(name)
        if relative.is_absolute() or '..' in relative.parts or any(c in name for c in '\\:') or name.casefold() in seen:
            raise ValueError('Ruta de archivo invalida: ' + name)
        seen.add(name.casefold())
        source = (payload / name).resolve()
        if not source.is_relative_to(payload) or not source.is_file() or digest(source) != expected:
            raise ValueError('Archivo incompleto o modificado: ' + name)
    catalog = read_json(payload / 'catalogo18.json')
    templates = catalog.get('templates', [])
    if len(templates) != 18 or sum(t.get('pages', 0) for t in templates) != 523:
        raise ValueError('No estan los 18 procedimientos y sus 523 paginas de base.')
    for template in templates:
        name = template['filename']
        if Path(name).name != name or '\\' in name or ':' in name:
            raise ValueError('Nombre de plantilla invalido.')
        key = 'plantillas/' + name
        if key not in files or digest(payload / key) != template['sha256']:
            raise ValueError('Falta o esta modificada la plantilla: ' + name)
    return files


def configure_templates(data_root, templates, catalog):
    """Keep a valid existing selection; back up an unusable preference file."""
    target = Path(data_root) / 'datos_locales' / 'base18.json'
    if target.exists():
        try:
            selected = Path(read_json(target)['templates'])
            if all((selected / t['filename']).is_file() and digest(selected / t['filename']) == t['sha256'] for t in catalog['templates']):
                return
        except (OSError, ValueError, TypeError, KeyError):
            pass
        backup = target.with_name('base18.antes-' + uuid.uuid4().hex[:8] + '.json')
        shutil.copy2(target, backup)
    write_atomic(target, json.dumps({'templates': str(templates)}, ensure_ascii=False, indent=2))


def run(command, env=None):
    subprocess.run([str(arg) for arg in command], env=env, check=True)


def desktop_shortcut(launcher, runner):
    # Paths are read from environment variables, never interpolated into PS code.
    env = os.environ.copy()
    env['SASISOPA_SHORTCUT_TARGET'] = str(launcher)
    script = "$w=New-Object -ComObject WScript.Shell; $p=Join-Path ([Environment]::GetFolderPath('Desktop')) 'SASISOPA actualizado.lnk'; $s=$w.CreateShortcut($p); $s.TargetPath=$env:SASISOPA_SHORTCUT_TARGET; $s.WorkingDirectory=Split-Path $env:SASISOPA_SHORTCUT_TARGET; $s.Save()"
    runner(['powershell.exe', '-NoProfile', '-Command', script], env=env)


def install(payload, local_data, runner=run, shortcut=desktop_shortcut):
    payload, local_data = Path(payload).resolve(), Path(local_data).resolve()
    files = verify_payload(payload)
    root = local_data / 'Programs' / 'SASISOPA-Actualizado'
    root.mkdir(parents=True, exist_ok=True)
    # A distinct runtime avoids replacing files used by a running installation.
    name = VERSION + '-' + uuid.uuid4().hex[:8]
    current = root / name
    app = current / 'Aplicacion'
    environment = current / 'entorno'
    data_root = local_data / 'SASISOPA' / 'Datos'
    activated = False
    preference_snapshot = None
    try:
        print('Copiando el programa y los 18 procedimientos...', flush=True)
        for relative in files:
            destination = app / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(payload / relative, destination)
        print('Preparando el entorno de Python...', flush=True)
        runner([sys.executable, '-m', 'venv', environment])
        python = environment / 'Scripts' / 'python.exe'
        if not python.is_file() or not (python.parent / 'pythonw.exe').is_file():
            raise RuntimeError('No se pudo crear el entorno de Python para Windows.')
        print('Instalando dependencias. Espera a que termine...', flush=True)
        runner([python, '-m', 'pip', 'install', '-r', app / 'requirements.txt'])
        data_root.mkdir(parents=True, exist_ok=True)
        report = current / 'comprobacion-windows.json'
        # Smoke tests use a temporary data directory, not the station's files.
        test_data = current / 'datos-prueba'
        env = os.environ.copy()
        env['SASISOPA_DATA_DIR'] = str(test_data)
        env['PYTHONUTF8'] = '1'
        print('Comprobando ventana, vista previa, datos, firmas y PDF...', flush=True)
        runner([python, app / 'lanzamiento.py', '--smoke-test', report], env=env)
        result = read_json(report)
        expected = ('ok', 'window', 'preview', 'save_load', 'synthetic_pdf', 'large_blue_signatures', 'manual_attendance') + RULES
        if result.get('system') != 'Windows' or result.get('version') != VERSION or not all(result.get(key) is True for key in expected):
            raise RuntimeError('La comprobacion del programa no se completo. No se activo esta instalacion.')
        shutil.rmtree(test_data, ignore_errors=True)
        preference = data_root / 'datos_locales' / 'base18.json'
        preference_snapshot = (preference, preference.read_bytes() if preference.exists() else None)
        configure_templates(data_root, app / 'plantillas', read_json(app / 'catalogo18.json'))
        launcher = root / 'Abrir-SASISOPA.cmd'
        command = ('@echo off\r\nset "PYTHONUTF8=1"\r\nset "SASISOPA_DATA_DIR=%LOCALAPPDATA%\\SASISOPA\\Datos"\r\n'
                   f'start "" "%~dp0{name}\\entorno\\Scripts\\pythonw.exe" "%~dp0{name}\\Aplicacion\\lanzamiento.py"\r\n')
        write_atomic(launcher, command)
        activated = True
        shortcut_created = True
        try:
            shortcut(launcher, runner)
        except (OSError, subprocess.CalledProcessError):
            shortcut_created = False
            print('No se pudo crear el acceso directo. Puedes usar ABRIR.bat.', flush=True)
        installed = {'version': VERSION, 'installed': True, 'windows_smoke_passed': True,
                     'data_directory': str(data_root), 'application': str(app),
                     'launcher': str(launcher), 'desktop_shortcut': shortcut_created}
        write_atomic(root / 'instalacion-actual.json', json.dumps(installed, ensure_ascii=False, indent=2))
        print('Instalacion terminada. Abre SASISOPA actualizado o ABRIR.bat.', flush=True)
        return installed
    except Exception as exc:
        if not activated:
            if preference_snapshot is not None:
                path, before = preference_snapshot
                if before is None:
                    path.unlink(missing_ok=True)
                elif not path.exists() or path.read_bytes() != before:
                    write_atomic(path, before)
            try:
                diagnostics = data_root / 'diagnosticos' / ('instalacion-' + name)
                diagnostics.mkdir(parents=True, exist_ok=True)
                (diagnostics / 'error.txt').write_text(str(exc), encoding='utf-8')
                smoke = current / 'comprobacion-windows.json'
                if smoke.exists():
                    shutil.copy2(smoke, diagnostics / smoke.name)
                print('Diagnostico guardado en: ' + str(diagnostics), file=sys.stderr)
            except OSError:
                pass
            # This directory was uniquely created for this attempt; user data and
            # the previously activated runtime are never removed.
            shutil.rmtree(current, ignore_errors=True)
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--payload', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--verify-only', action='store_true')
    args = parser.parse_args()
    if args.verify_only:
        print('Paquete verificado:', len(verify_payload(args.payload)), 'archivos.')
        return 0
    if sys.platform != 'win32' or not os.environ.get('LOCALAPPDATA'):
        raise RuntimeError('La instalacion debe ejecutarse en Windows con INSTALAR.bat.')
    install(args.payload, os.environ['LOCALAPPDATA'])
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except Exception as exc:
        print('ERROR:', exc, file=sys.stderr)
        sys.exit(1)
