"""Separate packaged resources from user documents and settings."""
import os
from pathlib import Path
import sys

RESOURCE_ROOT = Path(__file__).resolve().parent


def user_root():
    configured = os.environ.get('SASISOPA_DATA_DIR', '').strip()
    if configured:
        directory = Path(configured).expanduser()
        if not directory.is_absolute():
            raise ValueError('SASISOPA_DATA_DIR debe indicar una carpeta absoluta.')
        return directory
    if getattr(sys, 'frozen', False):
        local = Path(os.environ.get('LOCALAPPDATA', Path.home() / 'AppData' / 'Local'))
        return local / 'SASISOPA' / 'Datos'
    return RESOURCE_ROOT
