"""Version of the source prepared for the next Windows build."""
VERSION = '0.2.13'
