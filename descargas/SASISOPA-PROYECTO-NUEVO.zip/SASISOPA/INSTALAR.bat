@echo off
cd /d "%~dp0"
echo Instalando SASISOPA actualizado. Se necesita conexion a Internet.
echo Cierra SASISOPA si lo tienes abierto y espera a que termine.
set "SASISOPA_PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if exist "%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe" set "SASISOPA_PS=%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe"
"%SASISOPA_PS%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0Instalar-Windows.ps1"
if errorlevel 1 (
  echo.
  echo No se completo la instalacion. Conserva el mensaje de error mostrado.
  pause
  exit /b 1
)
echo.
echo Instalacion terminada. Abre SASISOPA actualizado desde el escritorio.
pause
