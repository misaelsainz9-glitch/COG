$ErrorActionPreference = 'Stop'
try {
    if ($env:OS -ne 'Windows_NT' -or ![Environment]::Is64BitOperatingSystem) { throw 'Se requiere Windows 10/11 de 64 bits.' }
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $payload = Join-Path $PSScriptRoot 'Aplicacion'
    if (!(Test-Path "$payload/instalar_usuario.py")) { throw 'Extrae todo el ZIP antes de ejecutar INSTALAR.bat.' }
    $candidates = @()
    $python = $null
    $py = Get-Command py.exe -ErrorAction SilentlyContinue
    if ($py) {
        $savedPreference = $ErrorActionPreference
        try {
            $ErrorActionPreference = 'Continue'
            $probe = & $py.Source -3.12 -c 'import sys,tkinter,venv; assert sys.maxsize>2**32; print(sys.executable)' 2>$null
            if ($LASTEXITCODE -eq 0 -and $probe) { $candidates += ($probe | Select-Object -Last 1).Trim() }
        } finally { $ErrorActionPreference = $savedPreference }
    }
    foreach ($key in @('HKCU:\Software\Python\PythonCore\3.12\InstallPath','HKLM:\Software\Python\PythonCore\3.12\InstallPath')) {
        if (Test-Path $key) {
            $value = (Get-ItemProperty $key -ErrorAction SilentlyContinue).ExecutablePath
            if ($value) { $candidates += $value }
        }
    }
    $privatePython = Join-Path $env:LOCALAPPDATA 'Programs\SASISOPA-Python312\python.exe'
    $candidates += $privatePython
    foreach ($candidate in ($candidates | Select-Object -Unique)) {
        if (!(Test-Path -LiteralPath $candidate)) { continue }
        $savedPreference = $ErrorActionPreference
        try {
            $ErrorActionPreference = 'Continue'
            & $candidate -c 'import sys,tkinter,venv; assert sys.version_info[:2]==(3,12) and sys.maxsize>2**32' 2>$null
            if ($LASTEXITCODE -eq 0) { $python = $candidate; break }
        } finally { $ErrorActionPreference = $savedPreference }
    }
    if (!$python) {
        Write-Host 'Descargando Python desde python.org...'
        $temporary = Join-Path ([IO.Path]::GetTempPath()) ('SASISOPA-Python-' + [guid]::NewGuid() + '.exe')
        try {
            Invoke-WebRequest -UseBasicParsing 'https://www.python.org/ftp/python/3.12.10/python-3.12.10-amd64.exe' -OutFile $temporary
            $signature = Get-AuthenticodeSignature -LiteralPath $temporary
            if ($signature.Status -ne 'Valid' -or $signature.SignerCertificate.Subject -notmatch 'Python Software Foundation') { throw 'No se pudo verificar la firma del instalador oficial de Python.' }
            $target = Split-Path $privatePython -Parent
            $process = Start-Process -FilePath $temporary -ArgumentList @('/passive','InstallAllUsers=0',"TargetDir=`"$target`"",'Include_launcher=0','Include_tcltk=1','Include_pip=1','Include_test=0','Shortcuts=0') -Wait -PassThru
            if ($process.ExitCode -notin @(0,3010)) { throw "Python no se instalo correctamente: $($process.ExitCode)" }
            $candidates = @($privatePython)
            foreach ($key in @('HKCU:\Software\Python\PythonCore\3.12\InstallPath','HKLM:\Software\Python\PythonCore\3.12\InstallPath')) {
                if (Test-Path $key) { $candidates += (Get-ItemProperty $key).ExecutablePath }
            }
            foreach ($candidate in ($candidates | Select-Object -Unique)) {
                if ($candidate -and (Test-Path -LiteralPath $candidate)) {
                    & $candidate -c 'import sys,tkinter,venv; assert sys.version_info[:2]==(3,12) and sys.maxsize>2**32'
                    if ($LASTEXITCODE -eq 0) { $python = $candidate; break }
                }
            }
            if (!$python) { throw 'No se encontro Python 3.12 de 64 bits con Tk despues de instalar.' }
        } finally { if (Test-Path -LiteralPath $temporary) { Remove-Item -LiteralPath $temporary -Force } }
    }
    $system32 = Join-Path $env:SystemRoot 'System32'
    if (!(Test-Path "$system32/msvcp140.dll") -or !(Test-Path "$system32/vcruntime140_1.dll")) {
        Write-Host 'Preparando Microsoft Visual C++, necesario para el motor PDF...'
        Write-Host 'Windows puede pedir autorizacion para instalar este componente de Microsoft.'
        $runtime = Join-Path ([IO.Path]::GetTempPath()) ('SASISOPA-VC-' + [guid]::NewGuid() + '.exe')
        try {
            Invoke-WebRequest -UseBasicParsing 'https://aka.ms/vs/17/release/vc_redist.x64.exe' -OutFile $runtime
            $signature = Get-AuthenticodeSignature -LiteralPath $runtime
            if ($signature.Status -ne 'Valid' -or $signature.SignerCertificate.Subject -notmatch 'Microsoft Corporation') { throw 'No se pudo verificar el componente oficial de Microsoft.' }
            $process = Start-Process -FilePath $runtime -Verb RunAs -ArgumentList @('/install','/passive','/norestart') -Wait -PassThru
            if ($process.ExitCode -notin @(0,3010,1638)) { throw "No se pudo instalar Microsoft Visual C++: $($process.ExitCode)" }
        } finally { if (Test-Path -LiteralPath $runtime) { Remove-Item -LiteralPath $runtime -Force } }
    }
    & $python "$payload/instalar_usuario.py" --payload $payload
    if ($LASTEXITCODE -ne 0) { throw 'La instalacion no termino; revisa los errores anteriores.' }
} catch {
    Write-Host ("ERROR: " + $_.Exception.Message) -ForegroundColor Red
    exit 1
}
